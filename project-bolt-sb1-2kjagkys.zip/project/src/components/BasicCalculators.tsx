import React, { useState } from 'react';
import { Calculator, Percent, Divide } from 'lucide-react';

const BasicCalculators: React.FC = () => {
  // Simple Calculator State
  const [calcDisplay, setCalcDisplay] = useState<string>('0');
  const [calcPrevious, setCalcPrevious] = useState<string | null>(null);
  const [calcOperation, setCalcOperation] = useState<string | null>(null);
  const [calcWaitingForOperand, setCalcWaitingForOperand] = useState<boolean>(false);

  // Percentage Calculator State
  const [percentageValue, setPercentageValue] = useState<string>('');
  const [percentageOf, setPercentageOf] = useState<string>('');
  const [percentageResult, setPercentageResult] = useState<number | null>(null);

  // Fraction Calculator State
  const [frac1Num, setFrac1Num] = useState<string>('');
  const [frac1Den, setFrac1Den] = useState<string>('');
  const [frac2Num, setFrac2Num] = useState<string>('');
  const [frac2Den, setFrac2Den] = useState<string>('');
  const [fracOperation, setFracOperation] = useState<string>('+');
  const [fracResult, setFracResult] = useState<string>('');

  // Simple Calculator Functions
  const inputNumber = (num: string) => {
    if (calcWaitingForOperand) {
      setCalcDisplay(String(num));
      setCalcWaitingForOperand(false);
    } else {
      setCalcDisplay(calcDisplay === '0' ? String(num) : calcDisplay + num);
    }
  };

  const inputDot = () => {
    if (calcWaitingForOperand) {
      setCalcDisplay('0.');
      setCalcWaitingForOperand(false);
    } else if (calcDisplay.indexOf('.') === -1) {
      setCalcDisplay(calcDisplay + '.');
    }
  };

  const clear = () => {
    setCalcDisplay('0');
    setCalcPrevious(null);
    setCalcOperation(null);
    setCalcWaitingForOperand(false);
  };

  const performOperation = (nextOperation: string) => {
    const inputValue = parseFloat(calcDisplay);

    if (calcPrevious === null) {
      setCalcPrevious(String(inputValue));
    } else if (calcOperation) {
      const previousValue = parseFloat(calcPrevious);
      let result: number;

      switch (calcOperation) {
        case '+':
          result = previousValue + inputValue;
          break;
        case '-':
          result = previousValue - inputValue;
          break;
        case '*':
          result = previousValue * inputValue;
          break;
        case '/':
          result = previousValue / inputValue;
          break;
        default:
          return;
      }

      setCalcDisplay(String(result));
      setCalcPrevious(String(result));
    }

    setCalcWaitingForOperand(true);
    setCalcOperation(nextOperation);
  };

  const calculate = () => {
    if (calcPrevious !== null && calcOperation) {
      performOperation('=');
      setCalcOperation(null);
      setCalcPrevious(null);
      setCalcWaitingForOperand(true);
    }
  };

  // Percentage Calculator Functions
  const calculatePercentage = () => {
    const value = parseFloat(percentageValue);
    const of = parseFloat(percentageOf);
    if (!isNaN(value) && !isNaN(of)) {
      setPercentageResult((value / 100) * of);
    }
  };

  React.useEffect(() => {
    if (percentageValue && percentageOf) {
      calculatePercentage();
    }
  }, [percentageValue, percentageOf]);

  // Fraction Calculator Functions
  const gcd = (a: number, b: number): number => {
    return b === 0 ? a : gcd(b, a % b);
  };

  const simplifyFraction = (numerator: number, denominator: number): string => {
    const divisor = gcd(Math.abs(numerator), Math.abs(denominator));
    const num = numerator / divisor;
    const den = denominator / divisor;
    
    if (den === 1) return String(num);
    if (den === -1) return String(-num);
    return `${num}/${den}`;
  };

  const calculateFraction = () => {
    const num1 = parseInt(frac1Num) || 0;
    const den1 = parseInt(frac1Den) || 1;
    const num2 = parseInt(frac2Num) || 0;
    const den2 = parseInt(frac2Den) || 1;

    let resultNum: number, resultDen: number;

    switch (fracOperation) {
      case '+':
        resultNum = num1 * den2 + num2 * den1;
        resultDen = den1 * den2;
        break;
      case '-':
        resultNum = num1 * den2 - num2 * den1;
        resultDen = den1 * den2;
        break;
      case '*':
        resultNum = num1 * num2;
        resultDen = den1 * den2;
        break;
      case '/':
        resultNum = num1 * den2;
        resultDen = den1 * num2;
        break;
      default:
        return;
    }

    if (resultDen === 0) {
      setFracResult('Undefined');
      return;
    }

    setFracResult(simplifyFraction(resultNum, resultDen));
  };

  React.useEffect(() => {
    if (frac1Num && frac1Den && frac2Num && frac2Den) {
      calculateFraction();
    }
  }, [frac1Num, frac1Den, frac2Num, frac2Den, fracOperation]);

  const resetPercentage = () => {
    setPercentageValue('');
    setPercentageOf('');
    setPercentageResult(null);
  };

  const resetFraction = () => {
    setFrac1Num('');
    setFrac1Den('');
    setFrac2Num('');
    setFrac2Den('');
    setFracResult('');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Basic Calculators</h2>
        <p className="text-gray-600">Essential mathematical tools for everyday calculations</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
        {/* Simple Arithmetic Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Calculator className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-semibold text-gray-800">Simple Calculator</h3>
          </div>
          
          <div className="mb-4">
            <input
              type="text"
              value={calcDisplay}
              readOnly
              className="w-full text-right text-2xl font-mono bg-gray-100 border-0 rounded-lg p-4"
            />
          </div>

          <div className="grid grid-cols-4 gap-2">
            <button onClick={clear} className="col-span-2 bg-red-500 hover:bg-red-600 text-white p-3 rounded-lg transition-colors">Clear</button>
            <button onClick={() => performOperation('/')} className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-lg transition-colors">÷</button>
            <button onClick={() => performOperation('*')} className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-lg transition-colors">×</button>
            
            {[7, 8, 9].map(num => (
              <button key={num} onClick={() => inputNumber(String(num))} className="bg-gray-200 hover:bg-gray-300 p-3 rounded-lg transition-colors">{num}</button>
            ))}
            <button onClick={() => performOperation('-')} className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-lg transition-colors">−</button>
            
            {[4, 5, 6].map(num => (
              <button key={num} onClick={() => inputNumber(String(num))} className="bg-gray-200 hover:bg-gray-300 p-3 rounded-lg transition-colors">{num}</button>
            ))}
            <button onClick={() => performOperation('+')} className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-lg transition-colors">+</button>
            
            {[1, 2, 3].map(num => (
              <button key={num} onClick={() => inputNumber(String(num))} className="bg-gray-200 hover:bg-gray-300 p-3 rounded-lg transition-colors">{num}</button>
            ))}
            <button onClick={calculate} className="row-span-2 bg-green-500 hover:bg-green-600 text-white p-3 rounded-lg transition-colors">=</button>
            
            <button onClick={() => inputNumber('0')} className="col-span-2 bg-gray-200 hover:bg-gray-300 p-3 rounded-lg transition-colors">0</button>
            <button onClick={inputDot} className="bg-gray-200 hover:bg-gray-300 p-3 rounded-lg transition-colors">.</button>
          </div>
        </div>

        {/* Percentage Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Percent className="w-6 h-6 text-green-600" />
            <h3 className="text-xl font-semibold text-gray-800">Percentage Calculator</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">What is</label>
              <input
                type="number"
                value={percentageValue}
                onChange={(e) => setPercentageValue(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter percentage"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">% of</label>
              <input
                type="number"
                value={percentageOf}
                onChange={(e) => setPercentageOf(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter number"
              />
            </div>

            {percentageResult !== null && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-sm text-green-800">Result:</p>
                <p className="text-2xl font-bold text-green-900">{percentageResult.toFixed(2)}</p>
              </div>
            )}

            <button
              onClick={resetPercentage}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Fraction Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Divide className="w-6 h-6 text-purple-600" />
            <h3 className="text-xl font-semibold text-gray-800">Fraction Calculator</h3>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Numerator</label>
                <input
                  type="number"
                  value={frac1Num}
                  onChange={(e) => setFrac1Num(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Denominator</label>
                <input
                  type="number"
                  value={frac1Den}
                  onChange={(e) => setFrac1Den(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="text-center">
              <select
                value={fracOperation}
                onChange={(e) => setFracOperation(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <option value="+">+</option>
                <option value="-">−</option>
                <option value="*">×</option>
                <option value="/">÷</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <input
                  type="number"
                  value={frac2Num}
                  onChange={(e) => setFrac2Num(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Numerator"
                />
              </div>
              <div>
                <input
                  type="number"
                  value={frac2Den}
                  onChange={(e) => setFrac2Den(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Denominator"
                />
              </div>
            </div>

            {fracResult && (
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <p className="text-sm text-purple-800">Result:</p>
                <p className="text-2xl font-bold text-purple-900 font-mono">{fracResult}</p>
              </div>
            )}

            <button
              onClick={resetFraction}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BasicCalculators;
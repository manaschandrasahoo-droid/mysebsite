import React, { useState } from 'react';
import { DollarSign, TrendingUp, Home } from 'lucide-react';
import { LoanResult, InvestmentResult, MortgageResult } from '../types';

const FinancialCalculators: React.FC = () => {
  // Loan Calculator State
  const [loanAmount, setLoanAmount] = useState<string>('');
  const [loanRate, setLoanRate] = useState<string>('');
  const [loanTerm, setLoanTerm] = useState<string>('');
  const [loanResult, setLoanResult] = useState<LoanResult | null>(null);

  // Investment Calculator State
  const [investInitial, setInvestInitial] = useState<string>('');
  const [investMonthly, setInvestMonthly] = useState<string>('');
  const [investRate, setInvestRate] = useState<string>('');
  const [investYears, setInvestYears] = useState<string>('');
  const [investResult, setInvestResult] = useState<InvestmentResult | null>(null);

  // Mortgage Calculator State
  const [mortgageAmount, setMortgageAmount] = useState<string>('');
  const [mortgageRate, setMortgageRate] = useState<string>('');
  const [mortgageTerm, setMortgageTerm] = useState<string>('');
  const [mortgageDown, setMortgageDown] = useState<string>('');
  const [mortgageResult, setMortgageResult] = useState<MortgageResult | null>(null);

  // Loan Calculator Functions
  const calculateLoan = () => {
    const principal = parseFloat(loanAmount);
    const annualRate = parseFloat(loanRate) / 100;
    const years = parseFloat(loanTerm);

    if (isNaN(principal) || isNaN(annualRate) || isNaN(years)) return;

    const monthlyRate = annualRate / 12;
    const numPayments = years * 12;

    if (annualRate === 0) {
      const monthlyPayment = principal / numPayments;
      setLoanResult({
        monthlyPayment,
        totalInterest: 0,
        totalAmount: principal,
      });
      return;
    }

    const monthlyPayment =
      (principal * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) /
      (Math.pow(1 + monthlyRate, numPayments) - 1);

    const totalAmount = monthlyPayment * numPayments;
    const totalInterest = totalAmount - principal;

    setLoanResult({
      monthlyPayment,
      totalInterest,
      totalAmount,
    });
  };

  React.useEffect(() => {
    if (loanAmount && loanRate && loanTerm) {
      calculateLoan();
    }
  }, [loanAmount, loanRate, loanTerm]);

  // Investment Calculator Functions
  const calculateInvestment = () => {
    const initial = parseFloat(investInitial) || 0;
    const monthly = parseFloat(investMonthly) || 0;
    const annualRate = parseFloat(investRate) / 100;
    const years = parseFloat(investYears);

    if (isNaN(annualRate) || isNaN(years)) return;

    const monthlyRate = annualRate / 12;
    const numPayments = years * 12;

    // Future value of initial investment
    const futureInitial = initial * Math.pow(1 + monthlyRate, numPayments);

    // Future value of monthly contributions (annuity)
    let futureMonthly = 0;
    if (monthly > 0 && monthlyRate > 0) {
      futureMonthly = monthly * ((Math.pow(1 + monthlyRate, numPayments) - 1) / monthlyRate);
    } else if (monthly > 0) {
      futureMonthly = monthly * numPayments;
    }

    const futureValue = futureInitial + futureMonthly;
    const totalContributions = initial + (monthly * numPayments);
    const totalInterest = futureValue - totalContributions;

    setInvestResult({
      futureValue,
      totalInterest,
      totalContributions,
    });
  };

  React.useEffect(() => {
    if (investRate && investYears && (investInitial || investMonthly)) {
      calculateInvestment();
    }
  }, [investInitial, investMonthly, investRate, investYears]);

  // Mortgage Calculator Functions
  const calculateMortgage = () => {
    const homePrice = parseFloat(mortgageAmount);
    const downPayment = parseFloat(mortgageDown) || 0;
    const loanAmount = homePrice - downPayment;
    const annualRate = parseFloat(mortgageRate) / 100;
    const years = parseFloat(mortgageTerm);

    if (isNaN(loanAmount) || isNaN(annualRate) || isNaN(years) || loanAmount <= 0) return;

    const monthlyRate = annualRate / 12;
    const numPayments = years * 12;

    if (annualRate === 0) {
      const monthlyPayment = loanAmount / numPayments;
      setMortgageResult({
        monthlyPayment,
        totalInterest: 0,
        totalAmount: loanAmount,
        principalAndInterest: monthlyPayment,
      });
      return;
    }

    const monthlyPayment =
      (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) /
      (Math.pow(1 + monthlyRate, numPayments) - 1);

    const totalAmount = monthlyPayment * numPayments;
    const totalInterest = totalAmount - loanAmount;

    setMortgageResult({
      monthlyPayment,
      totalInterest,
      totalAmount,
      principalAndInterest: monthlyPayment,
    });
  };

  React.useEffect(() => {
    if (mortgageAmount && mortgageRate && mortgageTerm) {
      calculateMortgage();
    }
  }, [mortgageAmount, mortgageRate, mortgageTerm, mortgageDown]);

  const resetLoan = () => {
    setLoanAmount('');
    setLoanRate('');
    setLoanTerm('');
    setLoanResult(null);
  };

  const resetInvestment = () => {
    setInvestInitial('');
    setInvestMonthly('');
    setInvestRate('');
    setInvestYears('');
    setInvestResult(null);
  };

  const resetMortgage = () => {
    setMortgageAmount('');
    setMortgageRate('');
    setMortgageTerm('');
    setMortgageDown('');
    setMortgageResult(null);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Financial Calculators</h2>
        <p className="text-gray-600">Plan your financial future with precise calculations</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
        {/* Loan Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <DollarSign className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-semibold text-gray-800">Loan Calculator</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Loan Amount ($)</label>
              <input
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter loan amount"
                min="0"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Annual Interest Rate (%)</label>
              <input
                type="number"
                value={loanRate}
                onChange={(e) => setLoanRate(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter interest rate"
                min="0"
                step="0.01"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Loan Term (years)</label>
              <input
                type="number"
                value={loanTerm}
                onChange={(e) => setLoanTerm(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter loan term"
                min="0.1"
                step="0.1"
              />
            </div>

            {loanResult && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
                <div className="text-sm">
                  <span className="font-medium">Monthly Payment:</span> ${loanResult.monthlyPayment.toFixed(2)}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Total Interest:</span> ${loanResult.totalInterest.toFixed(2)}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Total Amount:</span> ${loanResult.totalAmount.toFixed(2)}
                </div>
              </div>
            )}

            <button
              onClick={resetLoan}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Investment Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <TrendingUp className="w-6 h-6 text-green-600" />
            <h3 className="text-xl font-semibold text-gray-800">Investment Calculator</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Initial Investment ($)</label>
              <input
                type="number"
                value={investInitial}
                onChange={(e) => setInvestInitial(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter initial amount"
                min="0"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Monthly Contribution ($)</label>
              <input
                type="number"
                value={investMonthly}
                onChange={(e) => setInvestMonthly(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter monthly amount"
                min="0"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Annual Return Rate (%)</label>
              <input
                type="number"
                value={investRate}
                onChange={(e) => setInvestRate(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter expected return"
                min="0"
                step="0.01"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Investment Period (years)</label>
              <input
                type="number"
                value={investYears}
                onChange={(e) => setInvestYears(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter number of years"
                min="0.1"
                step="0.1"
              />
            </div>

            {investResult && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 space-y-2">
                <div className="text-sm">
                  <span className="font-medium">Future Value:</span> ${investResult.futureValue.toFixed(2)}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Total Contributions:</span> ${investResult.totalContributions.toFixed(2)}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Total Interest Earned:</span> ${investResult.totalInterest.toFixed(2)}
                </div>
              </div>
            )}

            <button
              onClick={resetInvestment}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Mortgage Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Home className="w-6 h-6 text-purple-600" />
            <h3 className="text-xl font-semibold text-gray-800">Mortgage Calculator</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Home Price ($)</label>
              <input
                type="number"
                value={mortgageAmount}
                onChange={(e) => setMortgageAmount(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter home price"
                min="0"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Down Payment ($)</label>
              <input
                type="number"
                value={mortgageDown}
                onChange={(e) => setMortgageDown(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter down payment"
                min="0"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Annual Interest Rate (%)</label>
              <input
                type="number"
                value={mortgageRate}
                onChange={(e) => setMortgageRate(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter interest rate"
                min="0"
                step="0.01"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Loan Term (years)</label>
              <input
                type="number"
                value={mortgageTerm}
                onChange={(e) => setMortgageTerm(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter loan term"
                min="0.1"
                step="0.1"
              />
            </div>

            {mortgageResult && (
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 space-y-2">
                <div className="text-sm">
                  <span className="font-medium">Monthly Payment:</span> ${mortgageResult.monthlyPayment.toFixed(2)}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Total Interest:</span> ${mortgageResult.totalInterest.toFixed(2)}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Total Amount:</span> ${mortgageResult.totalAmount.toFixed(2)}
                </div>
              </div>
            )}

            <button
              onClick={resetMortgage}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialCalculators;
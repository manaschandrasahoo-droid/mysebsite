import React from 'react';
import { Calculator, Home, DollarSign, Heart, RefreshCw } from 'lucide-react';

interface NavigationProps {
  activeCategory: string;
  onCategoryChange: (category: string) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeCategory, onCategoryChange }) => {
  const categories = [
    { id: 'basic', name: 'Basic', icon: Calculator },
    { id: 'scientific', name: 'Scientific', icon: Home },
    { id: 'financial', name: 'Financial', icon: DollarSign },
    { id: 'health', name: 'Health', icon: Heart },
    { id: 'conversion', name: 'Conversion', icon: RefreshCw },
  ];

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row items-center justify-between py-4">
          <div className="flex items-center space-x-2 mb-4 sm:mb-0">
            <Calculator className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              All-in-One Calculators
            </h1>
          </div>
          
          <div className="flex flex-wrap justify-center sm:justify-end gap-2">
            {categories.map((category) => {
              const Icon = category.icon;
              const isActive = activeCategory === category.id;
              
              return (
                <button
                  key={category.id}
                  onClick={() => onCategoryChange(category.id)}
                  className={`
                    flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200
                    ${isActive 
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-md' 
                      : 'text-gray-700 hover:bg-gray-100 hover:text-blue-600'
                    }
                  `}
                >
                  <Icon className="w-4 h-4" />
                  <span className="font-medium">{category.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
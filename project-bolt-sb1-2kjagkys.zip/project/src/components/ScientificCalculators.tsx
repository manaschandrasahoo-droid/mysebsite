import React, { useState } from 'react';
import { Activity, BarChart3, Zap } from 'lucide-react';

const ScientificCalculators: React.FC = () => {
  // Trigonometric Calculator State
  const [trigValue, setTrigValue] = useState<string>('');
  const [trigUnit, setTrigUnit] = useState<string>('degrees');
  const [trigResults, setTrigResults] = useState<any>({});

  // Logarithmic Calculator State
  const [logValue, setLogValue] = useState<string>('');
  const [logBase, setLogBase] = useState<string>('10');
  const [logResults, setLogResults] = useState<any>({});

  // Exponential Calculator State
  const [expBase, setExpBase] = useState<string>('');
  const [expExponent, setExpExponent] = useState<string>('');
  const [expResults, setExpResults] = useState<any>({});

  // Trigonometric Functions
  const calculateTrig = () => {
    const value = parseFloat(trigValue);
    if (isNaN(value)) return;

    const angleInRadians = trigUnit === 'degrees' ? (value * Math.PI) / 180 : value;
    
    const results = {
      sin: Math.sin(angleInRadians),
      cos: Math.cos(angleInRadians),
      tan: Math.tan(angleInRadians),
      asin: Math.asin(Math.sin(angleInRadians)),
      acos: Math.acos(Math.cos(angleInRadians)),
      atan: Math.atan(Math.tan(angleInRadians)),
    };

    if (trigUnit === 'degrees') {
      results.asin = (results.asin * 180) / Math.PI;
      results.acos = (results.acos * 180) / Math.PI;
      results.atan = (results.atan * 180) / Math.PI;
    }

    setTrigResults(results);
  };

  React.useEffect(() => {
    if (trigValue) {
      calculateTrig();
    }
  }, [trigValue, trigUnit]);

  // Logarithmic Functions
  const calculateLog = () => {
    const value = parseFloat(logValue);
    const base = parseFloat(logBase);
    if (isNaN(value) || isNaN(base) || value <= 0 || base <= 0 || base === 1) return;

    const results = {
      log10: Math.log10(value),
      ln: Math.log(value),
      logCustom: Math.log(value) / Math.log(base),
    };

    setLogResults(results);
  };

  React.useEffect(() => {
    if (logValue && logBase) {
      calculateLog();
    }
  }, [logValue, logBase]);

  // Exponential Functions
  const calculateExp = () => {
    const base = parseFloat(expBase);
    const exponent = parseFloat(expExponent);
    if (isNaN(base) || isNaN(exponent)) return;

    const results = {
      power: Math.pow(base, exponent),
      squareRoot: Math.sqrt(base),
      cubeRoot: Math.cbrt(base),
      nthRoot: exponent !== 0 ? Math.pow(base, 1 / exponent) : undefined,
    };

    setExpResults(results);
  };

  React.useEffect(() => {
    if (expBase && expExponent) {
      calculateExp();
    }
  }, [expBase, expExponent]);

  const resetTrig = () => {
    setTrigValue('');
    setTrigResults({});
  };

  const resetLog = () => {
    setLogValue('');
    setLogBase('10');
    setLogResults({});
  };

  const resetExp = () => {
    setExpBase('');
    setExpExponent('');
    setExpResults({});
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Scientific Calculators</h2>
        <p className="text-gray-600">Advanced mathematical functions for scientific calculations</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
        {/* Trigonometric Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Activity className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-semibold text-gray-800">Trigonometric Functions</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Angle</label>
              <input
                type="number"
                value={trigValue}
                onChange={(e) => setTrigValue(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter angle"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Unit</label>
              <select
                value={trigUnit}
                onChange={(e) => setTrigUnit(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="degrees">Degrees</option>
                <option value="radians">Radians</option>
              </select>
            </div>

            {Object.keys(trigResults).length > 0 && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">sin:</span> {trigResults.sin?.toFixed(6)}
                  </div>
                  <div>
                    <span className="font-medium">cos:</span> {trigResults.cos?.toFixed(6)}
                  </div>
                  <div>
                    <span className="font-medium">tan:</span> {trigResults.tan?.toFixed(6)}
                  </div>
                  <div>
                    <span className="font-medium">asin:</span> {trigResults.asin?.toFixed(6)}
                  </div>
                  <div>
                    <span className="font-medium">acos:</span> {trigResults.acos?.toFixed(6)}
                  </div>
                  <div>
                    <span className="font-medium">atan:</span> {trigResults.atan?.toFixed(6)}
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={resetTrig}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Logarithmic Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <BarChart3 className="w-6 h-6 text-green-600" />
            <h3 className="text-xl font-semibold text-gray-800">Logarithmic Functions</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Value</label>
              <input
                type="number"
                value={logValue}
                onChange={(e) => setLogValue(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter positive number"
                min="0.000001"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Custom Base (for log_base)</label>
              <input
                type="number"
                value={logBase}
                onChange={(e) => setLogBase(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter base"
                min="0.000001"
                step="any"
              />
            </div>

            {Object.keys(logResults).length > 0 && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 space-y-2">
                <div>
                  <span className="font-medium">log₁₀:</span> {logResults.log10?.toFixed(6)}
                </div>
                <div>
                  <span className="font-medium">ln (natural log):</span> {logResults.ln?.toFixed(6)}
                </div>
                <div>
                  <span className="font-medium">log_{logBase}:</span> {logResults.logCustom?.toFixed(6)}
                </div>
              </div>
            )}

            <button
              onClick={resetLog}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Exponential Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Zap className="w-6 h-6 text-purple-600" />
            <h3 className="text-xl font-semibold text-gray-800">Exponential Functions</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Base</label>
              <input
                type="number"
                value={expBase}
                onChange={(e) => setExpBase(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter base number"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Exponent</label>
              <input
                type="number"
                value={expExponent}
                onChange={(e) => setExpExponent(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter exponent"
                step="any"
              />
            </div>

            {Object.keys(expResults).length > 0 && (
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 space-y-2">
                <div>
                  <span className="font-medium">Power (base^exponent):</span> {expResults.power?.toFixed(6)}
                </div>
                <div>
                  <span className="font-medium">Square Root (√base):</span> {expResults.squareRoot?.toFixed(6)}
                </div>
                <div>
                  <span className="font-medium">Cube Root (∛base):</span> {expResults.cubeRoot?.toFixed(6)}
                </div>
                {expResults.nthRoot !== undefined && (
                  <div>
                    <span className="font-medium">Nth Root (base^(1/exponent)):</span> {expResults.nthRoot?.toFixed(6)}
                  </div>
                )}
              </div>
            )}

            <button
              onClick={resetExp}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScientificCalculators;
import React, { useState } from 'react';
import { Ruler, DollarSign, Thermometer } from 'lucide-react';

const ConversionCalculators: React.FC = () => {
  // Unit Converter State
  const [unitValue, setUnitValue] = useState<string>('');
  const [unitCategory, setUnitCategory] = useState<string>('length');
  const [fromUnit, setFromUnit] = useState<string>('m');
  const [toUnit, setToUnit] = useState<string>('ft');
  const [unitResult, setUnitResult] = useState<number | null>(null);

  // Currency Converter State
  const [currencyAmount, setCurrencyAmount] = useState<string>('');
  const [fromCurrency, setFromCurrency] = useState<string>('USD');
  const [toCurrency, setToCurrency] = useState<string>('EUR');
  const [currencyResult, setCurrencyResult] = useState<number | null>(null);
  const [exchangeRate, setExchangeRate] = useState<number | null>(null);

  // Temperature Converter State
  const [tempValue, setTempValue] = useState<string>('');
  const [fromTemp, setFromTemp] = useState<string>('celsius');
  const [tempResults, setTempResults] = useState<any>({});

  // Unit conversion factors (to base unit)
  const unitConversions: { [key: string]: { [key: string]: number } } = {
    length: {
      m: 1,
      km: 0.001,
      cm: 100,
      mm: 1000,
      in: 39.3701,
      ft: 3.28084,
      yd: 1.09361,
      mi: 0.000621371,
    },
    weight: {
      kg: 1,
      g: 1000,
      lb: 2.20462,
      oz: 35.274,
      ton: 0.001,
      st: 0.157473,
    },
    volume: {
      l: 1,
      ml: 1000,
      gal: 0.264172,
      qt: 1.05669,
      pt: 2.11338,
      cup: 4.22675,
      'fl oz': 33.814,
      tbsp: 67.628,
      tsp: 202.884,
    },
  };

  // Currency exchange rates (mock data - in production, use a real API)
  const currencyRates: { [key: string]: number } = {
    USD: 1,
    EUR: 0.85,
    GBP: 0.73,
    JPY: 110,
    CAD: 1.25,
    AUD: 1.35,
    CHF: 0.92,
    CNY: 6.45,
    INR: 74.5,
    BRL: 5.2,
  };

  // Unit Converter Functions
  const convertUnit = () => {
    const value = parseFloat(unitValue);
    if (isNaN(value)) return;

    const conversions = unitConversions[unitCategory];
    if (!conversions) return;

    // Convert to base unit, then to target unit
    const baseValue = value / conversions[fromUnit];
    const result = baseValue * conversions[toUnit];
    
    setUnitResult(result);
  };

  React.useEffect(() => {
    if (unitValue) {
      convertUnit();
    }
  }, [unitValue, unitCategory, fromUnit, toUnit]);

  // Update units when category changes
  React.useEffect(() => {
    const units = Object.keys(unitConversions[unitCategory] || {});
    if (units.length >= 2) {
      setFromUnit(units[0]);
      setToUnit(units[1]);
    }
  }, [unitCategory]);

  // Currency Converter Functions
  const convertCurrency = () => {
    const amount = parseFloat(currencyAmount);
    if (isNaN(amount)) return;

    // Convert through USD as base currency
    const usdAmount = amount / currencyRates[fromCurrency];
    const result = usdAmount * currencyRates[toCurrency];
    const rate = currencyRates[toCurrency] / currencyRates[fromCurrency];
    
    setCurrencyResult(result);
    setExchangeRate(rate);
  };

  React.useEffect(() => {
    if (currencyAmount) {
      convertCurrency();
    }
  }, [currencyAmount, fromCurrency, toCurrency]);

  // Temperature Converter Functions
  const convertTemperature = () => {
    const value = parseFloat(tempValue);
    if (isNaN(value)) return;

    let celsius: number;
    
    // Convert to Celsius first
    switch (fromTemp) {
      case 'celsius':
        celsius = value;
        break;
      case 'fahrenheit':
        celsius = (value - 32) * 5/9;
        break;
      case 'kelvin':
        celsius = value - 273.15;
        break;
      default:
        return;
    }

    // Convert to all units
    const results = {
      celsius: celsius,
      fahrenheit: celsius * 9/5 + 32,
      kelvin: celsius + 273.15,
    };

    setTempResults(results);
  };

  React.useEffect(() => {
    if (tempValue) {
      convertTemperature();
    }
  }, [tempValue, fromTemp]);

  const resetUnit = () => {
    setUnitValue('');
    setUnitResult(null);
  };

  const resetCurrency = () => {
    setCurrencyAmount('');
    setCurrencyResult(null);
    setExchangeRate(null);
  };

  const resetTemperature = () => {
    setTempValue('');
    setTempResults({});
  };

  const getUnitOptions = () => {
    const conversions = unitConversions[unitCategory];
    return Object.keys(conversions || {});
  };

  const currencies = Object.keys(currencyRates);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Conversion Calculators</h2>
        <p className="text-gray-600">Convert between different units and measurements</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
        {/* Unit Converter */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Ruler className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-semibold text-gray-800">Unit Converter</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
              <select
                value={unitCategory}
                onChange={(e) => setUnitCategory(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="length">Length</option>
                <option value="weight">Weight</option>
                <option value="volume">Volume</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Value</label>
              <input
                type="number"
                value={unitValue}
                onChange={(e) => setUnitValue(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter value to convert"
                step="any"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">From</label>
                <select
                  value={fromUnit}
                  onChange={(e) => setFromUnit(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {getUnitOptions().map(unit => (
                    <option key={unit} value={unit}>{unit}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">To</label>
                <select
                  value={toUnit}
                  onChange={(e) => setToUnit(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {getUnitOptions().map(unit => (
                    <option key={unit} value={unit}>{unit}</option>
                  ))}
                </select>
              </div>
            </div>

            {unitResult !== null && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">Result:</p>
                <p className="text-2xl font-bold text-blue-900">
                  {unitResult.toFixed(6)} {toUnit}
                </p>
              </div>
            )}

            <button
              onClick={resetUnit}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Currency Converter */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <DollarSign className="w-6 h-6 text-green-600" />
            <h3 className="text-xl font-semibold text-gray-800">Currency Converter</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
              <input
                type="number"
                value={currencyAmount}
                onChange={(e) => setCurrencyAmount(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter amount to convert"
                min="0"
                step="any"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">From</label>
                <select
                  value={fromCurrency}
                  onChange={(e) => setFromCurrency(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  {currencies.map(currency => (
                    <option key={currency} value={currency}>{currency}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">To</label>
                <select
                  value={toCurrency}
                  onChange={(e) => setToCurrency(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  {currencies.map(currency => (
                    <option key={currency} value={currency}>{currency}</option>
                  ))}
                </select>
              </div>
            </div>

            {currencyResult !== null && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 space-y-2">
                <div>
                  <p className="text-sm text-green-800">Result:</p>
                  <p className="text-2xl font-bold text-green-900">
                    {currencyResult.toFixed(2)} {toCurrency}
                  </p>
                </div>
                {exchangeRate && (
                  <div className="text-xs text-green-600">
                    Exchange Rate: 1 {fromCurrency} = {exchangeRate.toFixed(4)} {toCurrency}
                  </div>
                )}
              </div>
            )}

            <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
              <p>Note: Exchange rates are simulated for demo purposes. Use real financial APIs for actual conversions.</p>
            </div>

            <button
              onClick={resetCurrency}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Temperature Converter */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Thermometer className="w-6 h-6 text-purple-600" />
            <h3 className="text-xl font-semibold text-gray-800">Temperature Converter</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Temperature</label>
              <input
                type="number"
                value={tempValue}
                onChange={(e) => setTempValue(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter temperature"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">From Unit</label>
              <select
                value={fromTemp}
                onChange={(e) => setFromTemp(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <option value="celsius">Celsius (°C)</option>
                <option value="fahrenheit">Fahrenheit (°F)</option>
                <option value="kelvin">Kelvin (K)</option>
              </select>
            </div>

            {Object.keys(tempResults).length > 0 && (
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 space-y-3">
                <div className="text-center">
                  <div className="space-y-2">
                    <div className="bg-white rounded p-2">
                      <span className="text-sm font-medium">Celsius:</span>
                      <p className="text-lg font-bold text-purple-900">{tempResults.celsius?.toFixed(2)}°C</p>
                    </div>
                    <div className="bg-white rounded p-2">
                      <span className="text-sm font-medium">Fahrenheit:</span>
                      <p className="text-lg font-bold text-purple-900">{tempResults.fahrenheit?.toFixed(2)}°F</p>
                    </div>
                    <div className="bg-white rounded p-2">
                      <span className="text-sm font-medium">Kelvin:</span>
                      <p className="text-lg font-bold text-purple-900">{tempResults.kelvin?.toFixed(2)}K</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={resetTemperature}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConversionCalculators;
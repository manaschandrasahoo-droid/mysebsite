import React, { useState } from 'react';
import { Heart, Activity, Scale } from 'lucide-react';
import { BMIResult, CalorieResult } from '../types';

const HealthCalculators: React.FC = () => {
  // BMI Calculator State
  const [height, setHeight] = useState<string>('');
  const [weight, setWeight] = useState<string>('');
  const [heightUnit, setHeightUnit] = useState<string>('cm');
  const [weightUnit, setWeightUnit] = useState<string>('kg');
  const [bmiResult, setBmiResult] = useState<BMIResult | null>(null);

  // Caloric Needs Calculator State
  const [age, setAge] = useState<string>('');
  const [gender, setGender] = useState<string>('male');
  const [calorieHeight, setCalorieHeight] = useState<string>('');
  const [calorieWeight, setCalorieWeight] = useState<string>('');
  const [activityLevel, setActivityLevel] = useState<string>('sedentary');
  const [calorieResult, setCalorieResult] = useState<CalorieResult | null>(null);

  // Body Fat Calculator State
  const [bodyFatGender, setBodyFatGender] = useState<string>('male');
  const [waist, setWaist] = useState<string>('');
  const [neck, setNeck] = useState<string>('');
  const [hips, setHips] = useState<string>('');
  const [bfHeight, setBfHeight] = useState<string>('');
  const [bodyFatResult, setBodyFatResult] = useState<number | null>(null);

  // BMI Calculator Functions
  const calculateBMI = () => {
    let heightInM = parseFloat(height);
    let weightInKg = parseFloat(weight);

    if (isNaN(heightInM) || isNaN(weightInKg) || heightInM <= 0 || weightInKg <= 0) return;

    // Convert height to meters
    if (heightUnit === 'cm') {
      heightInM = heightInM / 100;
    } else if (heightUnit === 'ft') {
      heightInM = heightInM * 0.3048;
    } else if (heightUnit === 'in') {
      heightInM = heightInM * 0.0254;
    }

    // Convert weight to kg
    if (weightUnit === 'lbs') {
      weightInKg = weightInKg * 0.453592;
    }

    const bmi = weightInKg / (heightInM * heightInM);

    let category: string;
    let color: string;

    if (bmi < 18.5) {
      category = 'Underweight';
      color = 'text-blue-600';
    } else if (bmi < 25) {
      category = 'Normal weight';
      color = 'text-green-600';
    } else if (bmi < 30) {
      category = 'Overweight';
      color = 'text-yellow-600';
    } else {
      category = 'Obese';
      color = 'text-red-600';
    }

    setBmiResult({ bmi, category, color });
  };

  React.useEffect(() => {
    if (height && weight) {
      calculateBMI();
    }
  }, [height, weight, heightUnit, weightUnit]);

  // Caloric Needs Calculator Functions
  const calculateCalories = () => {
    const ageNum = parseFloat(age);
    const heightNum = parseFloat(calorieHeight);
    const weightNum = parseFloat(calorieWeight);

    if (isNaN(ageNum) || isNaN(heightNum) || isNaN(weightNum)) return;

    let bmr: number;

    // Mifflin-St Jeor Equation
    if (gender === 'male') {
      bmr = 10 * weightNum + 6.25 * heightNum - 5 * ageNum + 5;
    } else {
      bmr = 10 * weightNum + 6.25 * heightNum - 5 * ageNum - 161;
    }

    const activityMultipliers: { [key: string]: number } = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      very_active: 1.9,
    };

    const dailyCalories = bmr * activityMultipliers[activityLevel];

    const activityLabels: { [key: string]: string } = {
      sedentary: 'Sedentary (little/no exercise)',
      light: 'Light activity (light exercise 1-3 days/week)',
      moderate: 'Moderate activity (moderate exercise 3-5 days/week)',
      active: 'Active (hard exercise 6-7 days/week)',
      very_active: 'Very active (very hard exercise, physical job)',
    };

    setCalorieResult({
      bmr,
      dailyCalories,
      activityLevel: activityLabels[activityLevel],
    });
  };

  React.useEffect(() => {
    if (age && calorieHeight && calorieWeight) {
      calculateCalories();
    }
  }, [age, gender, calorieHeight, calorieWeight, activityLevel]);

  // Body Fat Calculator Functions (US Navy Method)
  const calculateBodyFat = () => {
    const waistNum = parseFloat(waist);
    const neckNum = parseFloat(neck);
    const hipsNum = parseFloat(hips);
    const heightNum = parseFloat(bfHeight);

    if (isNaN(waistNum) || isNaN(neckNum) || isNaN(heightNum)) return;

    let bodyFat: number;

    if (bodyFatGender === 'male') {
      bodyFat = 495 / (1.0324 - 0.19077 * Math.log10(waistNum - neckNum) + 0.15456 * Math.log10(heightNum)) - 450;
    } else {
      if (isNaN(hipsNum)) return;
      bodyFat = 495 / (1.29579 - 0.35004 * Math.log10(waistNum + hipsNum - neckNum) + 0.22100 * Math.log10(heightNum)) - 450;
    }

    setBodyFatResult(Math.max(0, bodyFat));
  };

  React.useEffect(() => {
    if (waist && neck && bfHeight && (bodyFatGender === 'male' || hips)) {
      calculateBodyFat();
    }
  }, [bodyFatGender, waist, neck, hips, bfHeight]);

  const resetBMI = () => {
    setHeight('');
    setWeight('');
    setBmiResult(null);
  };

  const resetCalories = () => {
    setAge('');
    setCalorieHeight('');
    setCalorieWeight('');
    setCalorieResult(null);
  };

  const resetBodyFat = () => {
    setWaist('');
    setNeck('');
    setHips('');
    setBfHeight('');
    setBodyFatResult(null);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Health Calculators</h2>
        <p className="text-gray-600">Track and monitor your health metrics with precision</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
        {/* BMI Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Scale className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-semibold text-gray-800">BMI Calculator</h3>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Height</label>
                <input
                  type="number"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter height"
                  min="0"
                  step="any"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Unit</label>
                <select
                  value={heightUnit}
                  onChange={(e) => setHeightUnit(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="cm">cm</option>
                  <option value="m">m</option>
                  <option value="ft">ft</option>
                  <option value="in">in</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Weight</label>
                <input
                  type="number"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter weight"
                  min="0"
                  step="any"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Unit</label>
                <select
                  value={weightUnit}
                  onChange={(e) => setWeightUnit(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="kg">kg</option>
                  <option value="lbs">lbs</option>
                </select>
              </div>
            </div>

            {bmiResult && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-800">{bmiResult.bmi.toFixed(1)}</p>
                  <p className={`text-lg font-medium ${bmiResult.color}`}>{bmiResult.category}</p>
                </div>
                <div className="mt-3 text-xs text-gray-600">
                  <p>BMI Categories:</p>
                  <p>• Underweight: &lt; 18.5</p>
                  <p>• Normal: 18.5 - 24.9</p>
                  <p>• Overweight: 25.0 - 29.9</p>
                  <p>• Obese: ≥ 30.0</p>
                </div>
              </div>
            )}

            <button
              onClick={resetBMI}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Caloric Needs Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Activity className="w-6 h-6 text-green-600" />
            <h3 className="text-xl font-semibold text-gray-800">Caloric Needs Calculator</h3>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Age</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Years"
                  min="1"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Height (cm)</label>
              <input
                type="number"
                value={calorieHeight}
                onChange={(e) => setCalorieHeight(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter height in cm"
                min="0"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Weight (kg)</label>
              <input
                type="number"
                value={calorieWeight}
                onChange={(e) => setCalorieWeight(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter weight in kg"
                min="0"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Activity Level</label>
              <select
                value={activityLevel}
                onChange={(e) => setActivityLevel(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="sedentary">Sedentary</option>
                <option value="light">Light activity</option>
                <option value="moderate">Moderate activity</option>
                <option value="active">Active</option>
                <option value="very_active">Very active</option>
              </select>
            </div>

            {calorieResult && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 space-y-2">
                <div className="text-sm">
                  <span className="font-medium">BMR:</span> {Math.round(calorieResult.bmr)} calories/day
                </div>
                <div className="text-sm">
                  <span className="font-medium">Daily Calories:</span> {Math.round(calorieResult.dailyCalories)} calories/day
                </div>
                <div className="text-xs text-gray-600 mt-2">
                  <p>{calorieResult.activityLevel}</p>
                </div>
              </div>
            )}

            <button
              onClick={resetCalories}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Body Fat Calculator */}
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <div className="flex items-center space-x-2 mb-6">
            <Heart className="w-6 h-6 text-purple-600" />
            <h3 className="text-xl font-semibold text-gray-800">Body Fat Calculator</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
              <select
                value={bodyFatGender}
                onChange={(e) => setBodyFatGender(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Height (cm)</label>
              <input
                type="number"
                value={bfHeight}
                onChange={(e) => setBfHeight(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter height"
                min="0"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Waist (cm)</label>
              <input
                type="number"
                value={waist}
                onChange={(e) => setWaist(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter waist measurement"
                min="0"
                step="any"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Neck (cm)</label>
              <input
                type="number"
                value={neck}
                onChange={(e) => setNeck(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter neck measurement"
                min="0"
                step="any"
              />
            </div>

            {bodyFatGender === 'female' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Hips (cm)</label>
                <input
                  type="number"
                  value={hips}
                  onChange={(e) => setHips(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Enter hip measurement"
                  min="0"
                  step="any"
                />
              </div>
            )}

            {bodyFatResult !== null && (
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-800">{bodyFatResult.toFixed(1)}%</p>
                  <p className="text-sm text-purple-600">Body Fat Percentage</p>
                </div>
                <div className="mt-3 text-xs text-gray-600">
                  <p>Healthy ranges (approximate):</p>
                  <p>• Men: 10-20%</p>
                  <p>• Women: 16-30%</p>
                  <p className="mt-1 italic">Using US Navy method</p>
                </div>
              </div>
            )}

            <button
              onClick={resetBodyFat}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors"
            >
              Reset
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HealthCalculators;
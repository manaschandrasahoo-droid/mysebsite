// Type definitions for the calculator application
export interface Calculator {
  id: string;
  name: string;
  description: string;
}

export interface NavigationItem {
  id: string;
  name: string;
  description: string;
}

export interface BMIResult {
  bmi: number;
  category: string;
  color: string;
}

export interface LoanResult {
  monthlyPayment: number;
  totalInterest: number;
  totalAmount: number;
}

export interface InvestmentResult {
  futureValue: number;
  totalInterest: number;
  totalContributions: number;
}

export interface MortgageResult {
  monthlyPayment: number;
  totalInterest: number;
  totalAmount: number;
  principalAndInterest: number;
}

export interface CalorieResult {
  bmr: number;
  dailyCalories: number;
  activityLevel: string;
}
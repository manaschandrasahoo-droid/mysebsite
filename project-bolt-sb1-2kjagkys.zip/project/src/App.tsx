import React, { useState } from 'react';
import Navigation from './components/Navigation';
import BasicCalculators from './components/BasicCalculators';
import ScientificCalculators from './components/ScientificCalculators';
import FinancialCalculators from './components/FinancialCalculators';
import HealthCalculators from './components/HealthCalculators';
import ConversionCalculators from './components/ConversionCalculators';

function App() {
  const [activeCategory, setActiveCategory] = useState<string>('basic');

  const renderActiveCategory = () => {
    switch (activeCategory) {
      case 'basic':
        return <BasicCalculators />;
      case 'scientific':
        return <ScientificCalculators />;
      case 'financial':
        return <FinancialCalculators />;
      case 'health':
        return <HealthCalculators />;
      case 'conversion':
        return <ConversionCalculators />;
      default:
        return <BasicCalculators />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <Navigation 
        activeCategory={activeCategory} 
        onCategoryChange={setActiveCategory} 
      />
      
      <main className="pb-8">
        {renderActiveCategory()}
      </main>

      <footer className="bg-white border-t border-gray-200 py-8">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>&copy; 2025 All-in-One Calculators. Built with React, TypeScript, and Tailwind CSS.</p>
          <p className="text-sm mt-2">Accurate calculations for all your mathematical needs.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;